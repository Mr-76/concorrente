
package main

import (
 "fmt"
 "math/rand"
)



func produce(channel chan int) {
  rand.Seed(42)
  b := rand.Intn(10000)
  for i:= 0; i < b; i++{
   v := rand.Intn(200000)
   fmt.Println("produtor1 produz")
   channel <- v
  }

}



func produce2(channel chan int) {
  rand.Seed(42)
  b := rand.Intn(10000)
  for i:= 0; i < b; i++{
   v := rand.Intn(10)
   fmt.Println("produtor2 produz")
   channel <- v
  }

}


func consume(channel chan int){
	for {
		value:= <- channel
		if value % 2 == 0{
			fmt.Println(value)
		}
	}
}

func main() {
	ch := make(chan int)
	fmt.Printf("ehllo")
	go produce(ch)
	go produce2(ch)
	go consume(ch)
	for{}
}
